#NoTrayIcon
#SingleInstance Force

; Assign Right Alt (RAlt) for both normal functionality and custom actions
RAlt::
{
    KeyWait, RAlt, T0.2  ; Wait for 200ms to detect a hold
    if (ErrorLevel)  ; If the key is held down
    {
        Send {Alt down}  ; Start normal Alt functionality
        KeyWait, RAlt  ; Wait until the key is released
        Send {Alt up}  ; Release Alt
    }
    else  ; If the key is tapped quickly
    {
        Send ^#{Left}  ; Switch to the right desktop
        Send {Media_Play_Pause}  ; Pause the video
    }
}
return

; Assign Right Ctrl (RCtrl) key for switching to the left desktop and pausing the video
RCtrl::
{
    Send ^#{Right}  ; Switch to the left desktop
    Send, {Media_Play_Pause}  ; Pause the video
}
return

; Make sure RAlt switches to the right desktop by mimicking Ctrl + Win + Right
RAlt & RCtrl::
{
    Send ^#{Left}  ; Switch to the right desktop when both are pressed
}
return


