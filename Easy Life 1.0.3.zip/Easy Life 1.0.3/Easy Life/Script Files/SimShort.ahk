#NoTrayIcon
#UseHook
#SingleInstance Force

SetCapsLockState, AlwaysOff

; Caps Lock or Right Shift + G: Launch Google Chrome
CapsLock & g::
RShift & g::
Run, chrome.exe
return

; Caps Lock or Right Shift + W: Open WhatsApp
CapsLock & w::
RShift & w::
Send, ^{Esc}  
Sleep, 150
Send, whatsapp  
Sleep, 100  
Send, {Enter}  
return

; Caps Lock or Right Shift + B: Launch Brave browser
CapsLock & b::
RShift & b::
Run, brave.exe
return

; Caps Lock or Right Shift + T: Open Telegram
CapsLock & t::
RShift & t::
Send, ^{Esc}  
Sleep, 150  
Send, telegram  
Sleep, 100  
Send, {Enter}  
return

; Caps Lock or Right Shift + V: Open VScode
CapsLock & v::
RShift & v::
Send, ^{Esc}  
Sleep, 150  
Send, vscode
Sleep, 100  
Send, {Enter}  
return

; Caps Lock or Right Shift + C: Open ChatGPT in Brave
CapsLock & c::
RShift & c::
Run, chrome.exe "https://chat.openai.com"
return

; Default hotkeys
CapsLock & d::OpenDownloads()
RShift & d::OpenDownloads()

; Path template using default USERNAME
downloadsPathTemplate := "C:\Users\%USERNAME%\Downloads"

OpenDownloads() {
    global downloadsPathTemplate

    ; Replace %USERNAME% with actual user
    username := A_UserName
    userPath := StrReplace(downloadsPathTemplate, "%USERNAME%", username)

    ; Check if folder exists
    if FileExist(userPath)
    {
        Run, %userPath%
    }
    else
    {
        ; Clearer instructions in InputBox
        InputBox, userInput, Downloads Folder Not Found, Could not find Downloads folder >_<`n`nPlease type your Windows C:\Users\[USERNAME] folder name, , 450, 180
        if ErrorLevel
            return  ; user canceled
        else
        {
            ; If they typed a full path, use it directly
            if InStr(userInput, ":\") ; contains colon? full path
                newPath := userInput
            else
                newPath := "C:\Users\" . userInput . "\Downloads"

            ; Save it back for future use
            downloadsPathTemplate := newPath

            if FileExist(newPath)
                Run, %newPath%
            else
                MsgBox, 48, Error, Still could not find folder:`n%newPath%
        }
    }
}



; Caps Lock or Right Shift + E: Launch Microsoft Edge
CapsLock & e::
RShift & e::
Run, microsoft-edge:
return


; Caps Lock or Right Shift + L: Open LinkedIn in Chrome
CapsLock & l::
RShift & l::
Run, chrome.exe "https://www.linkedin.com"
return

; Caps Lock or Right Shift + N: Open Notepad
CapsLock & n::
RShift & n::
Run, notepad.exe
return

; Caps Lock or Right Shift + Y: Open YouTube in Brave
CapsLock & y::
RShift & y::
Run, brave.exe "https://youtube.com"
return

; Restore Caps Lock normal functionality when pressed alone
CapsLock::
SetCapsLockState, % GetKeyState("CapsLock", "T") ? "Off" : "On"
return


