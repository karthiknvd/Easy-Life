#NoTrayIcon        ; hide tray icon
#Persistent
#NoEnv
#SingleInstance Force

SetBatchLines, -1

global overlayID := ""
global overlayTrans := 0       ; start at 0 transparency
global step := 15              ; change per press

ShowDarknessLevel() {
    global overlayTrans
    percent := Round(overlayTrans/255*100)
    Tooltip, Darkness: %percent%`%
    SetTimer, RemoveTooltip, -1000  ; hide after 1 second
}

^PgDn::  ; Ctrl + Page Down = turn ON or darker
{
    if (overlayID = "")
    {
        ; Create overlay at 0 (transparent but active)
        Gui, Overlay: +AlwaysOnTop -Caption +ToolWindow +E0x20
        Gui, Overlay: Color, Black
        Gui, Overlay: Show, x0 y0 w%A_ScreenWidth% h%A_ScreenHeight%, BlackOverlay
        WinGet, overlayID, ID, BlackOverlay
        overlayTrans := 0
        WinSet, Transparent, %overlayTrans%, ahk_id %overlayID%
    }
    else
    {
        overlayTrans += step
        if (overlayTrans > 255)
            overlayTrans := 255
        WinSet, Transparent, %overlayTrans%, ahk_id %overlayID%
    }
    ShowDarknessLevel()
    return
}

^PgUp::  ; Ctrl + Page Up = brighter, turn OFF at 0
{
    if (overlayID != "")
    {
        overlayTrans -= step
        if (overlayTrans <= 0)
        {
            ; Fully transparent → destroy overlay
            Gui, Overlay: Destroy
            overlayID := ""
            overlayTrans := 0
            Tooltip, Darkness: 0
            SetTimer, RemoveTooltip, -1000
            return
        }
        WinSet, Transparent, %overlayTrans%, ahk_id %overlayID%
        ShowDarknessLevel()
    }
    return
}

RemoveTooltip:
Tooltip
Return


