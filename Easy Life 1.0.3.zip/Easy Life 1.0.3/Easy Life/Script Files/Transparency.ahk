#NoTrayIcon
#SingleInstance Force

SetTitleMatchMode, 2
global transparency

; Initialize with full opacity
transparency := 255

; Function to get current window transparency
GetTransparency() {
    WinGet, trans, Transparent, A
    if (trans = "")
        return 255
    return trans
}

; Function to show transparency level
ShowTransparency(transparency) {
    percent := Round(transparency / 255 * 100)
    ToolTip, Transparency: %percent%`%
    SetTimer, RemoveToolTip, -1000
}

PgUp::
    global transparency
    transparency := GetTransparency() + 10
    if (transparency > 255)
        transparency := 255
    WinSet, Transparent, %transparency%, A
    ShowTransparency(transparency)
return

PgDn::
    global transparency
    transparency := GetTransparency() - 10
    if (transparency < 0)
        transparency := 0
    WinSet, Transparent, %transparency%, A
    ShowTransparency(transparency)
return

RemoveToolTip:
    ToolTip
return


