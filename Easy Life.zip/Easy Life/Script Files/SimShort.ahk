#NoTrayIcon
#UseHook
#SingleInstance Force

SetCapsLockState, AlwaysOff

; Caps Lock or Right Shift + G: Launch Google Chrome
CapsLock & g::
RShift & g::
Run, chrome.exe
return

; Caps Lock or Right Shift + W: Open WhatsApp
CapsLock & w::
RShift & w::
Send, ^{Esc}  
Sleep, 150
Send, whatsapp  
Sleep, 100  
Send, {Enter}  
return

; Caps Lock or Right Shift + B: Launch Brave browser
CapsLock & b::
RShift & b::
Run, brave.exe
return

; Caps Lock or Right Shift + T: Open Telegram
CapsLock & t::
RShift & t::
Send, ^{Esc}  
Sleep, 150  
Send, telegram  
Sleep, 100  
Send, {Enter}  
return

; Caps Lock or Right Shift + T: Open Roblox
CapsLock & r::
RShift & r::
Send, ^{Esc}  
Sleep, 150  
Send, roblox 
Sleep, 100  
Send, {Enter}  
return

; Caps Lock or Right Shift + T: Open Telegram
CapsLock & v::
RShift & v::
Send, ^{Esc}  
Sleep, 150  
Send, vscode
Sleep, 100  
Send, {Enter}  
return

; Caps Lock or Right Shift + C: Open ChatGPT in Chrome
CapsLock & c::
RShift & c::
Run, chrome.exe "https://chat.openai.com"
return

; --- Settings ---
downloadsPath := "C:\Users\YOUR_USER\Downloads"  ; <-- set your path

; Hotkeys
CapsLock & d::
RShift & d::
    if FileExist(downloadsPath)
        Run, %downloadsPath%
    else
        MsgBox, 48, Error, Downloads folder not found:`n%downloadsPath%
return



; Caps Lock or Right Shift + E: Launch Microsoft Edge
CapsLock & e::
RShift & e::
Run, microsoft-edge:
return


; Caps Lock or Right Shift + L: Open Linkedin in Chrome
CapsLock & l::
RShift & l::
Run, chrome.exe "https://www.linkedin.com/"
return

; Caps Lock or Right Shift + N: Open Netflix in Chrome
CapsLock & n::
RShift & n::
Run, chrome.exe "https://www.netflix.com/"
return

; Caps Lock or Right Shift + A: Open Amazon in Chrome
CapsLock & a::
RShift & a::
Run, chrome.exe "https://www.amazon.com/"
return

; Caps Lock or Right Shift + Y: Open YouTube in Chrome
CapsLock & y::
RShift & y::
Run, chrome.exe "https://youtube.com"
return

; Restore Caps Lock normal functionality when pressed alone
CapsLock::
SetCapsLockState, % GetKeyState("CapsLock", "T") ? "Off" : "On"
return


