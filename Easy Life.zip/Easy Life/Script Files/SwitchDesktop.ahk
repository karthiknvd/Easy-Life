#NoTrayIcon
#SingleInstance Force

;---------------------------
; RIGHT ALT multi-function
;---------------------------
RAlt::
{
    KeyWait, RAlt, T0.2   ; Wait for 200ms
    if (ErrorLevel)       ; Held
    {
        Send {Alt down}
        KeyWait, RAlt
        Send {Alt up}
    }
    else                  ; Tap
    {
        Send ^#{Left}          ; Switch desktop
        Send {Media_Play_Pause}
    }
}
return


;---------------------------
; RIGHT CTRL — works normal + tap shortcut
;---------------------------
*RCtrl::
{
    KeyWait, RCtrl, T0.2     ; Held?
    if (ErrorLevel)
    {
        Send {Ctrl down}     ; Normal behavior
        KeyWait, RCtrl
        Send {Ctrl up}
    }
    else                     ; Quick tap
    {
        Send ^#{Right}       ; Switch desktop
        Send {Media_Play_Pause}
    }
}
return


;---------------------------
; RAlt + RCtrl combo
;---------------------------
RAlt & RCtrl::
{
    Send ^#{Left}
}
return
